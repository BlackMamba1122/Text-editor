#pragma once
#include "Utility.h"

class TextEditor
{
	friend class Document;
	friend class Lines;
	int CRow = 0, CCol = 0, NODs, CDoci;
	Document* Doc;
public:
	TextEditor(string Fname);
	void Run();
	void PrintShortcuts();
	void CommandModeShortcutsPrinter();
	void CommandMode();
	void MergeDocuments(string Fname1, string Fname2);
	void OpenMultipleDocs(_____);
};
