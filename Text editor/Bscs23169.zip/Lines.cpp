#include "Lines.h"

Lines::Lines() : line(), size(0)		{}

Lines::Lines(const Lines& A): line(A.line) , size(A.size)	{}

void Lines::InsertCharAt(std::list<Word*>::iterator wordIt, std::list<char>::iterator loc, char c)
{
	Word* targetWord = *wordIt;
	targetWord->addChar(loc, c);
	//list<Word*>::iterator it;
	//Word* w = *it;
	//w->addChar(loc, c);
}

void Lines::CharRemoverAt(std::list<Word*>::iterator wordIt, std::list<char>::iterator loc)
{
	Word* targetWord = *wordIt;
	targetWord->removeChar(loc);
}

void Lines::ToUpper(std::list<Word*>::iterator wordIt)
{
	(*wordIt)->toUpper((*wordIt)->begin());
}

void Lines::ToLower(std::list<Word*>::iterator wordIt)
{
	(*wordIt)->toLower((*wordIt)->begin());

}
