#pragma once
#include "Utility.h"
#include "List"
class Word
{
	list<char> word;
	int size;
public:
	Word();
	void addChar(list<char>::iterator loc,char c);
	void removeChar(list<char>::iterator loc);
	void printWord();
	int getSize();
	//void toUpper();
	//void toLower();
};

