#include<conio.h>
#include<iostream>
#include<fstream>
#include<string>
#include<windows.h>
using namespace std;
#pragma once
//Defined Colors can be used to chagne the color of console text.
#define BLACK 0
#define BLUE 1
#define GREEN 2
#define CYAN 3
#define RED 4
#define MAGENTA 5
#define BROWN 6
#define LIGHTGREY 7
#define DARKGREY 8
#define LIGHTBLUE 9
#define LIGHTGREEN 10
#define LIGHTCYAN 11
#define LIGHTRED 12
#define LIGHTMAGENTA 13
#define YELLOW 14
#define WHITE 15
#define BLINK 1286
//SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), RED); 
   //Built-In method to change the color of the text on console.
void gotoRowCol(int rpos, int cpos); // Already Provided 
class Liness {
	friend class TextEditor;
	friend class Document;
	char* Cs;
	int Size;
	static bool isChar(char c);
	static bool islower(char c);
	static bool isupper(char c);
public:
	Lines();
	Lines(const Lines& A);
	void InsertCharAt_i(int i, char ch);
	void CharRemoverAt_i(int i);
	void ToUpper(int li, int ci);
	void ToLower(int li, int ci);
	� SubStrings(string Tofind);
	void AddPrefix(string ToFind, string Prefix);
	void AddPostfix(string toFind, string PostFix);
	bool Replacefirst(string toFind, string toReplace);
	void ReplaceAll(string toFind, string toReplace);
	______ FindNextOnly(----);
	______ FindPrevOnly(----);
	______ FindNextAll(----);
	______ FindPrevAll(----);

	______  FindAndReplaceNextOnly(----);
	______  FindAndReplacePrevOnly(----);
	void FindAndReplaceNextAll(----);
	void FindAndReplacePrevAll(----);
	void PrintLine(----);
	void Writer(ofstream& wtr);
	~Lines();
};
class Documentt {
	friend class TextEditor;
	friend class Lines;
	Lines* Ls;
	int NOLs;
	string DName;
	Int dri = 0, dci = 0;
	void Deepcopy(Lines& NLs, const Lines& L);
public:
	Document(string fname);
	void Load(string Fname);
	void LoadEncodedFile(string Fname);
	void SimpleUpdater();
	void UpdaterEncodedFiles();
	void Enter_AddNewLine(int ri, int ci);
	void BackSpace_LineRemover(int Ln);
	void BackSpace_Concat(int Ln);
	void FindCaseSens(string Tofind);
	void FindInCaseSens(string Tofind);
	double AvgWordLen();
	int SmallestWordLen();
	int LargestWordLength();
	int WordCount();
	int SpecialCharCount();
	int SentencesCount();
	int ParagraphCount();
	void FindAllSubStrings(string toFind);
	void Prefix(string Tofind, string PreFix);
	void PostFix(string Tofind, string PostFix);
	void FindAndReplaceFirst(string tofind, string toreplace);
	void FindAndReplaceAll(string tofind, string toreplace);
	void FindReplaceNext(string find, string replace, int cr, int cc);
	void FindReplaceAllNext(string find, string replace, int cr, int cc);
	void FindReplacePrev(string find, string replace, int cr, int cc);
	void FindReplaceAllPrev(string find, string replace, int cr, int cc);
	void FindAndReplaceMenu(int cr, int cc) {
		cout << "Ctrl + N to find and replace only the next word." << endl;
		cout << "Ctrl + Q to find and replace All next words." << endl;
		cout << "Ctrl + P to find and replace only the previous 1 word." << endl;
		cout << "Ctrl + O to find and replace all of the previous words." << endl;
		//You can use any Shortcut keys.
	}
	void FindingSentence();
	void WordGame(int& cr, int& cc); //Feature no. 16
	void PrintDocument();
	void ExitDocument();
	void DeleteAllLines();
	~Documentt();
};
class TextEditor
{
	friend class Document;
	friend class Lines;
	int CRow = 0, CCol = 0, NODs, CDoci;
	Document* Doc;
public:
	TextEditorr(string Fname);
	void Run();
	void PrintShortcuts();
	void CommandModeShortcutsPrinter();
	void CommandMode();
	void MergeDocuments(string Fname1, string Fname2);
	void OpenMultipleDocs(_____);
};
