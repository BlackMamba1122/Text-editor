#pragma once
#include "Utility.h"
#include "Word.h"
class Lines
{
	friend class TextEditor;
	friend class Document;
	//;char* Cs;
	list<Word*>line;
	int size;
	//;static bool isChar(char c);
	//;static bool islower(char c);
	//;static bool isupper(char c);
public:
	Lines();
	Lines(const Lines& A);
	void InsertCharAt(std::list<Word*>::iterator wordIt, std::list<char>::iterator loc, char c);
	void CharRemoverAt(std::list<Word*>::iterator wordIt, std::list<char>::iterator loc);
	void ToUpper(std::list<Word*>::iterator wordIt);
	void ToLower(std::list<Word*>::iterator wordIt);
	//SubStrings(string Tofind);
	/*void AddPrefix(string ToFind, string Prefix);
	void AddPostfix(string toFind, string PostFix);
	bool Replacefirst(string toFind, string toReplace);
	void ReplaceAll(string toFind, string toReplace);
	______ FindNextOnly(----);
	______ FindPrevOnly(----);
	______ FindNextAll(----);
	______ FindPrevAll(----);
	______  FindAndReplaceNextOnly(----);
	______  FindAndReplacePrevOnly(----);
	void FindAndReplaceNextAll(----);
	void FindAndReplacePrevAll(----);
	void PrintLine(----);
	void Writer(ofstream& wtr);
	~Lines();*/
};
