#include "Word.h"

Word::Word() : word(NULL), size(0) {}

Word::Word(const Word& A) : word(A.word) , size(A.size)		{}

void Word::addChar(list<char>::iterator loc, char c)
{
	word.insert(loc, c);
	size++;
}

void Word::removeChar(list<char>::iterator loc)
{
	word.erase(loc);
	size--;
}

void Word::printWord()
{
	for(char c: word)
		cout << c;
}

int Word::getSize()
{
	return size;
}

std::list<char>::iterator Word::begin()
{
	return word.begin();
}

std::list<char>::iterator Word::end()
{
	return word.end();
}

void Word::toLower(list<char>::iterator loc)
{
	for (auto it = word.begin(); it != word.end(); ++it)
		*it = std::toupper(*it);
}

void Word::toUpper(list<char>::iterator loc)
{
	for (auto it = word.begin(); it != word.end(); ++it)
		*it = std::tolower(*it);
}
